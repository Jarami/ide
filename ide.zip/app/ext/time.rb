class Time
  def to_ms
    self.to_f.round(3).*(1000).to_i
  end 
end 