require 'json'

require_relative 'block_evaler'
require_relative 'route'

require_relative 'controllers/base'
require_relative 'controllers/home'
require_relative 'controllers/item'
require_relative 'controllers/bad'

require_relative 'ext/time'

class App

  DEFAULTS = {
    home: Dir.pwd
  }

  attr_reader :routes

  def initialize params = {}, &block
    params = {}.merge( DEFAULTS ).merge( params )
    params.merge!( BlockEvaler.new(&block).params ) if block_given?

    raise 'No route file defined! Write App.new( :routes => "path/to/routes.json" ). ' unless params[:routes] 

    @routes_file = File.join( params[:home], params[:routes] )
    raise 'Route file does not exist!' unless @routes_file

    @routes = Route.create_all( JSON.parse( File.read(@routes_file) ) )

    @mtime = File.mtime(@routes_file)
  end 

  def call env
    
    update_routes 

    request = Rack::Request.new(env)
    response = Rack::Response.new
    route = get_route(request) || BadRoute.new
  
    call_action_for(route, request, response)

    response

  end

  private
  def get_route request

    # ищем рут, который лучше всего подходит запросу
    route = nil
    routes.each do |r|
      if m = r.match(request)
        if route.nil? || route.parts.size < r.parts.size
          route = r
        end 
      end 
    end 
    route

  end 

  def call_action_for(route, request, response)
    
    if route.params 
      route.params.each do |param, message|
        raise ArgumentError, message unless request.params[param] 
      end 
    end 
    
    controller_class = Kernel.instance_eval(route.controller) rescue nil 
    raise "Bad value for controller class!" unless controller_class.is_a?(Class)
    controller_class.new.public_send(route.action, request, response)
    
  end

  def update_routes
    if @mtime < File.mtime(@routes_file)
      @routes = Route.create_all( JSON.parse( File.read(@routes_file) ) )
      @mtime = File.mtime(@routes_file)
    end 
  end 
end