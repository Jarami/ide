module Controllers 
  class Home < Base
    def index request, response
      
      response.write File.open("app/views/home/index.html", "r:utf-8"){|f| f.read }

    end 
  end 
end 