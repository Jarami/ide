require 'json' 

module Controllers 
  class Item < Base

    def tree request, response     
      item = __tree( request.params["folder"] )
      response.write JSON.generate( item )
    end 

    def dir request, response
      items = __dir( request.params["folder"] )
      response.write JSON.generate( items )
    end 

    def info request, response      
      request.params["folder"]
      response.write "info: " + request.params.to_s
    end 

    def create request, response
      response.write "create: " + request.params.to_s
    end 

    def delete request, response
      response.write "delete: " + request.params.to_s
    end 

    def update request, response
      response.write "update: " + request.params.to_s
    end 
    
    private 
    def __dir folder
      puts folder
      raise ArgumentError, "folder #{folder} does not exist" unless Dir.exist?(folder)
      
      items = []
      Dir.entries(folder).each do |entry|
        puts entry 
        puts item = File.join( folder, entry ) #.force_encoding(Encoding::UTF_8)
        items << item_info( item )
      end 
      order = {"up" => 0, "folder" => 1, "file" => 2}
      items.sort_by{|item| [ order[item[:class]], item[:name] ] }
    end 
    
    def __tree target, folder = nil 
    
      folder = target.split("/").first unless folder
    puts folder 
      item = item_info(folder)
      puts 1
      puts item[:children] = __dir(folder)
      puts 2
      unless folder == target
        item[:children].each do |child|
          if child[:class] == "folder" && target.start_with?(child[:abs])
            child.merge! __tree(target, child[:abs])
          end 
        end 
      end 
      return item
    end 

    def item_info item 
      
      if [".",".."].include? File.basename(item)
        class_name = "up"
      elsif File.directory? item 
        class_name = "folder"
      else 
        class_name = "file"
      end 
      
      { 
        :name  => File.basename(item), 
        :dir   => File.dirname(item), 
        :abs   => File.absolute_path(item), 
        :ctime => File.ctime(item).to_ms, 
        :atime => File.atime(item).to_ms, 
        :mtime => File.mtime(item).to_ms,
        :class => class_name
      }
    end 
    
  end 
end 