module Controllers 
  class Item < Base

    def tree request, response
      response.write "tree: " + request.params.to_s
    end 

    def dir request, response
      response.write "dir"
    end 

    def info request, response
      response.write "info"
    end 

    def create request, response
      response.write "create"
    end 

    def delete request, response
      response.write "delete"
    end 

    def update request, response
      response.write "update"
    end 

  end 
end 