require_relative 'base'

module Controllers 
  class Bad < Base
    def index request, response
      
      response.status = 400
      response.write @message

    end 
  end 
end 