module Controllers 
  class Bad < Base
    def index request, response
      
      response.status = 400
      response.write "Bad Request"

    end 
  end 
end 