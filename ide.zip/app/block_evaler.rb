class BlockEvaler
  attr_reader :params
  def initialize &block 
    @params = {}
    instance_eval(block)
  end 
  def method_missing param, *args 
    @params[ param ] = args.first
  end 
end 