class Route 
  def self.create_all(route_records)
    route_records.map{|route_record|
      new(route_record)
    }
  end 

  attr_reader :request_method, :path, :parts, :handler, :controller, :action
  def initialize route_record
    @request_method      = route_record["method"]
    @path                = route_record["path"]
    @handler             = route_record["handler"]
    @controller, @action = route_record["handler"].split("#")
    @parts = @path.scan(/\/\w+/)
  end 

  def match request 

    return nil if request_method != request.request_method

    if has_dynamic_segment?
      return nil if !request.path.start_with?(path)
    else 
      return nil if request.path != path
    end 

    true 

  end 
  # def === other

  # end 

  def has_dynamic_segment?
    path.include?(":") || path.include?("*")
  end
end 

class BadRoute
  attr_reader :request_method, :path, :handler, :controller, :action
  def initialize
    @request_method      = "index"
    @handler             = "Controllers::Bad#index"
    @controller, @action = "Controllers::Bad", "index"
  end 
end 