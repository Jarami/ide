class ExceptionHandler
  def initialize app 
    @app = app 
  end 
  def call env 
    @app.call(env)
  rescue Exception => ex 
    [
      500, 
      {"Content-Type"=>"text/plain"}, 
      [ex.class.to_s, ": ", ex.message, "\n"] + ex.backtrace.map{|line| "\t" + line + "\n"}
    ]
  end 
end 