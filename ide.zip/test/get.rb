require 'net/http'
require 'uri'

folder = File.absolute_path( File.dirname(__FILE__) )
folder = URI.encode_www_form_component( folder )

requests = [
  { uri: "http://localhost:9292/",                      test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } },
  
  { uri: "http://localhost:9292/tree?folder=" + folder, test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" }, show: true },
  { uri: "http://localhost:9292/tree",                  test: ->(resp){ "must be 500 got #{resp.code}" unless resp.code == "500" } },
  
  { uri: "http://localhost:9292/dir?folder=" + folder,  test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } },
  { uri: "http://localhost:9292/dir",                   test: ->(resp){ "must be 500 got #{resp.code}" unless resp.code == "500" } },
  
  { uri: "http://localhost:9292/info?item=" + folder,   test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } },
  { uri: "http://localhost:9292/info",                  test: ->(resp){ "must be 500 got #{resp.code}" unless resp.code == "500" } },
]

http = Net::HTTP.new("localhost", 9292)      
http.open_timeout = 10
http.read_timeout = 10

responses = []

begin

  http.start

  requests.each do |request|

    uri = URI(request[:uri])

    req = Net::HTTP::Get.new(uri.request_uri)
    resp = http.request(req)
    # puts request[:uri]
    # puts "Status: " + resp.code
    # puts "Message: " + resp.message
    # puts "Headers: " + Hash[ resp.each.map{|k,v| [k,v] } ].to_s
    # puts "Body:"
    # puts resp.body 
    
    responses << { resp: resp, uri: request[:uri], show: request[:show] }
    
    if message = request[:test].call(resp)
      STDOUT.write "F"
      responses.last.merge!( message: message, fail: true )
    else 
      STDOUT.write "."
    end 
  end 
  
ensure 
  http.finish 
end 

puts
puts

responses.each do |response|
  if response[:fail] 
    puts response[:uri]
    puts response[:message]
    puts response[:resp].body 
    puts 
  end 
end 

puts "==================================="

responses.each do |response|
  if response[:show] 
    puts response[:uri]
    puts response[:message]
    puts response[:resp].body 
    puts 
  end 
end 