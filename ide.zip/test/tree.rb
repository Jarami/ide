require 'net/http'

folder = File.absolute_path( File.dirname(__FILE__) )

# uri = URI("http://localhost:9292/tree"  )
uri = URI("http://localhost:9292/tree?folder=" + URI.encode_www_form_component( folder ) )
req = Net::HTTP::Get.new(uri)

resp = Net::HTTP.start(uri.host, uri.port) {|http|
  http.request(req)
}
puts resp.body 