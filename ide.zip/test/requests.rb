require 'net/http'
require 'uri'

require_relative '../app/ext/ext'

folder = File.absolute_path( File.dirname(__FILE__) )
folder = URI.encode_www_form_component( folder )

requests = [
  # GET
  { method: "GET", uri: "http://localhost:9292/",                      test: ->(resp){ "status must be 200 got #{resp.code}" unless resp.code == "200" } },
  
  { method: "GET", uri: "http://localhost:9292/tree?folder=" + folder, test: ->(resp){ "status must be 200 got #{resp.code}" unless resp.code == "200" }, show: true },
  { method: "GET", uri: "http://localhost:9292/tree",                  test: ->(resp){ "status must be 500 got #{resp.code}" unless resp.code == "500" } },
  
  { method: "GET", uri: "http://localhost:9292/dir?folder=" + folder,  test: ->(resp){ "status must be 200 got #{resp.code}" unless resp.code == "200" } },
  { method: "GET", uri: "http://localhost:9292/dir",                   test: ->(resp){ "status must be 500 got #{resp.code}" unless resp.code == "500" } },
  
  { method: "GET", uri: "http://localhost:9292/info?item=" + folder,   test: ->(resp){ "status must be 200 got #{resp.code}" unless resp.code == "200" } },
  { method: "GET", uri: "http://localhost:9292/info",                  test: ->(resp){ "status must be 500 got #{resp.code}" unless resp.code == "500" } },

  # POST
  { method: "POST", uri: "http://localhost:9292/create", body: "folder=#{folder}", test: ->(resp){ "status must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  { method: "POST", uri: "http://localhost:9292/create", body: "",                 test: ->(resp){ "status must be 500 got #{resp.code}" unless resp.code == "500" } } ,
  
  { method: "POST", uri: "http://localhost:9292/delete", body: "folder=#{folder}", test: ->(resp){ "status must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  { method: "POST", uri: "http://localhost:9292/delete", body: "",                 test: ->(resp){ "status must be 500 got #{resp.code}" unless resp.code == "500" } } ,
  
  { method: "POST", uri: "http://localhost:9292/update", body: "file=#{folder}",   test: ->(resp){ "status must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  { method: "POST", uri: "http://localhost:9292/update", body: "",                 test: ->(resp){ "status must be 500 got #{resp.code}" unless resp.code == "500" } } ,

]

http = Net::HTTP.new("localhost", 9292) 
http.open_timeout = 10
http.read_timeout = 10

responses = []

begin

  http.start

  requests.each do |request|

    uri = URI(request[:uri])

    case request[:method]
      when "GET" 
        req = Net::HTTP::Get.new(uri.request_uri)
      when "POST"
        req = Net::HTTP::Post.new(uri.request_uri)
        req.body = request[:body]
    end 
    resp = http.request(req)
    # puts request[:uri]
    # puts "Status: " + resp.code
    # puts "Message: " + resp.message
    # puts "Headers: " + Hash[ resp.each.map{|k,v| [k,v] } ].to_s
    # puts "Body:"
    # puts resp.body 
    
    responses << { resp: resp, uri: request[:uri], show: request[:show] }
    
    if message = request[:test].call(resp)
      STDOUT.write "F"
      responses.last.merge!( message: message, fail: true )
    else 
      STDOUT.write "."
    end 
  end 
  
ensure 
  http.finish 
end 

puts 
responses.each do |response|
  if response[:fail] || response[:show]
    puts response[:message].red if response[:message]
    puts "request: "
    puts URI.decode_www_form_component( response[:uri] )
    puts "response body: "
    puts response[:resp].body 
    puts 
  end 
end 