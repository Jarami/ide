require 'json'
require 'net/http'
require 'minitest/autorun'

require_relative '../app/app'

# config_file = 'config/config.json'
# config = JSON.parse( File.read(config_file) )
# app    = App.new( routes: config["routes"] )

# config file 
describe "ConfigFile" do 

  before do 
    @config_file = 'config/config.json'
    @config_file_abs = File.absolute_path(@config_file)
    @configs = JSON.parse( File.read(@config_file) ) rescue nil 
    @include_keys = ["routes"]
  end 

  it "must be nice" do 
    assert( File.exist?(@config_file), "Config file must exist: #{@config_file_abs}" )
    assert( File.size(@config_file) > 0, "Config file must not be empty: #{@config_file_abs}")
    assert( !!@configs, "config file must be json-parsable" ) 
    assert_equal( Hash, @configs.class, "config file must contain hash" )
    assert_equal( @include_keys, @include_keys & @configs.keys, "must contain keys: #{@include_keys}" ) 
  end 
end 

describe "Route_record" do 
  before do 
    config_file = 'config/config.json'
    @route_file = JSON.parse( File.read(config_file) )["routes"] rescue nil 
    @route_file_abs = File.absolute_path(@route_file) rescue nil 
    @routes = JSON.parse( File.read(@route_file) ) rescue nil 
  end
  it "must be awesome" do 
    assert( @route_file, "Config file must be defined" )
    assert( File.exist?(@route_file), "route file must exist: #{@route_file_abs}" )
    assert( File.size(@route_file) > 0, "routes file must not be empty: #{@route_file_abs}") 
    assert( !!@routes, "routes file content must be json-parsable" )
    assert_equal( Array, @routes.class, "routes file must contain array of routes") if @routes
    assert_equal( [Hash], @routes.map(&:class).uniq, "routes file must contain array of routes") if @routes

    included_keys = ['method', 'path', 'handler']
    @routes.each do |route|
      assert_equal( included_keys, included_keys & route.keys, "route keys #{route.keys} do not include #{included_keys-route.keys}" ) 
    end 

    allowed_methods = ["GET", "POST"]
    @routes.each do |route|
      assert_includes( allowed_methods, route["method"], "route method #{route["method"].inspect} must be in #{allowed_methods}"  )
    end 

    @routes.each do |route|
      assert_includes( "/", route["path"][0], "route path #{route["path"].inspect} must start with '/'"  ) if route["path"]
    end 

    @routes.each_with_index do |r, index|
      route = Route.new( r )
      assert_equal( r["method"],  route.request_method )
      assert_equal( r["path"],    route.path )
      assert_equal( r["handler"], route.handler )
    end 
  end   
end 

describe "route" do 
  before do 
    @route = Route.new({ "method" => "GET",  "path" => "/foo/bar", "handler" => "Controllers::Home#index"  })
  end 
  it "method must be GET" do 
    assert_equal( @route.request_method, "GET", "method must be GET" )
  end 
  it "path must be '/foo/bar'" do 
    assert_equal( @route.path, "/foo/bar", "path must be '/foo/bar'" )
  end 
  it "handler must be 'Controllers::Home#index'" do 
    assert_equal( @route.handler, "Controllers::Home#index", "handler must be 'Controllers::Home#index'" )
  end 
  it "controller must be 'Controllers::Home'" do 
    assert_equal( @route.controller, "Controllers::Home", "controller must be 'Controllers::Home'" )
  end 
  it "action must be 'index'" do 
    assert_equal( @route.action, "index", "action must be 'index'" )
  end 
  it "parts must be ['/foo','/bar']" do 
    assert_equal( @route.parts, ['/foo','/bar'], "parts must be ['/foo','/bar']" )
  end
end 

# config_file = 'config/config.json'
# config = JSON.parse( File.read(config_file) ) rescue nil 
# routes = JSON.parse( File.read( config["routes"] ) ) rescue nil 

# describe App do 
#   before do 
#     # config_file = 'config/config.json'
#     # config = JSON.parse( File.read(config_file) ) rescue nil 
#     # puts config["routes"] 
#     # @app = App.new( routes: config["routes"] ) rescue nil 
#   end 

#   describe "page" do 
#     it "must be availible" do 
#       uri = URI('http://localhost:9292')
#       assert_silent(){  Net::HTTP.get_response(uri) }
#     end 
#     routes.each do |route|
#       it "must respond" do 
#         uri = URI('http://localhost:9292' + route["path"] )
#         # resp = Net::HTTP.get_response(uri) rescue nil 
        
#         case route["method"]
#           when "GET"
#             req = Net::HTTP::Get.new(uri)
#           when "POST"
#             req = Net::HTTP::Post.new(uri)
#         end 
#         resp = Net::HTTP.start(uri.host, uri.port) {|http|
#           http.request(req)
#         }

#         assert( !!resp, "#{route['path'].inspect} must be avaliable")
#         assert_equal(Net::HTTPOK, resp.class, "#{route['path']} must be ok" )

#       end 
#     end 
#   end 
# end 
