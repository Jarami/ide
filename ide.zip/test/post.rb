require 'net/http'
require 'uri'

folder = File.absolute_path( File.dirname(__FILE__) )

requests = [
  { uri: "http://localhost:9292/create", body: "folder=#{folder}", test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  { uri: "http://localhost:9292/create", body: "",                 test: ->(resp){ "must be 500 got #{resp.code}" unless resp.code == "500" } } ,
  
  { uri: "http://localhost:9292/delete", body: "folder=#{folder}", test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  { uri: "http://localhost:9292/delete", body: "",                 test: ->(resp){ "must be 500 got #{resp.code}" unless resp.code == "500" } } ,
  
  { uri: "http://localhost:9292/update", body: "file=#{folder}",   test: ->(resp){ "must be 200 got #{resp.code}" unless resp.code == "200" } } ,
  { uri: "http://localhost:9292/update", body: "",                 test: ->(resp){ "must be 500 got #{resp.code}" unless resp.code == "500" } } ,
  
]

http = Net::HTTP.new("localhost", 9292)      
http.open_timeout = 10
http.read_timeout = 10

responses = []

begin

  http.start

  requests.each do |request|
    uri = URI(request[:uri])
    req = Net::HTTP::Post.new(uri.request_uri)
    req.body = request[:body]
    resp = http.request(req)
    
    # puts request[:uri]
    # puts "Status: " + resp.code
    # puts "Message: " + resp.message
    # puts "Headers: " + Hash[ resp.each.map{|k,v| [k,v] } ].to_s
    # puts "Body:"
    # puts resp.body 
    
    responses << { resp: resp, uri: request[:uri] }
    
    if message = request[:test].call(resp)
      STDOUT.write "F"
      responses.last.merge!( message: message, fail: true )
    else 
      STDOUT.write "."
    end 
    
  end 
  
ensure 
  http.finish 
end 

puts
puts

responses.each do |response|
  if response[:fail]
    puts response[:uri]
    puts response[:message]
    puts response[:resp].body
    puts 
  end 
end 