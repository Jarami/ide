require 'json'
require 'net/http'
require 'minitest/autorun'

require_relative '../app/app'

app = App.new( routes: '../config/routes.json' )

describe App do
  describe "Page avaliability" do 

    app.routes.each do |route|
      describe route.path do 
        it "must be availible" do 
          uri = URI('http://localhost:9292' + route.path)
          assert_silent(){  Net::HTTP.get_response(uri)  }
        end 
      end 
    end 

  end 
end 

