$( function(){

    // navigation-editor resizing 
    var splitter = document.createElement("DIV");
    navigation_editor_container.appendChild(splitter);
           
    Resizing.move({
      splitter: {
        elem: splitter, width: 10
      },
      elem1: {
        elem: navigation, min: 100, max: 100, size: "30%"
      },
      elem2: {
        elem: editor, min: 100, max: 100
      },
      motion: "horizontal",
      done: function(){
        // editor.resize();
        // output.adjust();
      }
    }); 

});