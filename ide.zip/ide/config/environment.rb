require_relative '../app/controllers/base'
require_relative '../app/controllers/home'
require_relative '../app/controllers/item'
require_relative '../app/controllers/bad'
